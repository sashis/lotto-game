# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lotto']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['lotto = lotto:run']}

setup_kwargs = {
    'name': 'lotto-game',
    'version': '0.1.0',
    'description': 'Lotto, a russian on-board game for console',
    'long_description': '# lotto-game\nНастольная игра "Лото", консольная версия\n',
    'author': 'Aleksandr Kropanev',
    'author_email': 'kropanev@mail.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/sashis/lotto-game',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.9.0,<4.0.0',
}


setup(**setup_kwargs)
